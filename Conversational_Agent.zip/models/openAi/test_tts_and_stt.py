import requests
import azure.cognitiveservices.speech as speechsdk

speech_key = "8nXcYzqKoS2oX8DSZRFl2LSKFIKCMWxRotBt4nbi47DgSipkTyBuJQQJ99BBAClhwhEXJ3w3AAAYACOGYh1X"
service_region = "ukwest"
speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_config.speech_synthesis_voice_name = "en-GB-SoniaNeural"
speech_config.speech_recognition_language = "en-US"
# 创建语音识别器
speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
print("Speak into your microphone.")
speech_result = speech_recognizer.recognize_once_async().get()

if speech_result.reason == speechsdk.ResultReason.RecognizedSpeech:
    user_request = speech_result.text
    print(f"✅ You said: {user_request}")

    # 这里可以整合你的推荐逻辑，比如根据用户说的内容搜索电影
    # 简单示例：假设用户说了"Interstellar"
    movie_query = user_request.strip().replace('.', '')

    API_KEY = "45439941b3d1dcb396e708bf8814a577"
    url = f"https://api.themoviedb.org/3/search/movie?api_key={API_KEY}&query={movie_query}&language=en-US"
    response = requests.get(url).json()

    if response['results']:
        movie = response['results'][0]
        title = movie['title']
        overview = movie['overview']
        recommendation = f"Here's your recommendation: '{title}'. Overview: {overview}"
    else:
        recommendation = "Sorry, I couldn't find that movie."

    print(recommendation)
    # 合成并播放语音
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
    tts_result = speech_synthesizer.speak_text_async(recommendation).get()
if tts_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("✅ Successfully provided the recommendation via speech.")
else:
    print("❌ Sorry, I couldn't understand your speech.")